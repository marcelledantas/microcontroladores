# importação de bibliotecas


# parâmetros iniciais do Telegram
chave = "COLOQUE A SUA CHAVE AQUI!"
id_da_conversa = "COLOQUE O ID DA SUA CONVERSA AQUI!"
endereco_base = "https://api.telegram.org/bot" + chave


# definição de funções


# criação de componentes
