# importação de bibliotecas
from os import system


# Mata todos os aplicativos "mplayer" e "arecord"
system("killall mplayer")
system("killall arecord")


# parâmetros iniciais do Telegram
chave = "COLOQUE A SUA CHAVE AQUI!"
id_da_conversa = "COLOQUE O ID DA SUA CONVERSA AQUI!"
endereco_base = "https://api.telegram.org/bot" + chave


# definição de funções


# criação de componentes


# loop infinito
