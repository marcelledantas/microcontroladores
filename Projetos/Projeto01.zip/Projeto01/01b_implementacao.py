# importação de bibliotecas
from os import system
from time import sleep


# para de tocar músicas que tenham ficado tocando da vez passada
system("killall mplayer")


# definição de funções


# criação de componentes


# loop infinito
while True:


    sleep(0.2)
